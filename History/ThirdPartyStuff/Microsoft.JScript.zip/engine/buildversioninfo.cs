﻿namespace Microsoft.JScript
{

    // From version.h

//#define rmj 8
//#define rmm 0
//#define rup 50826
//#define rpt 0
//#define szVerName ""
//#define szVerUser "VSBLD305"
    
    public static class BuildVersionInfo
    {
        public static int MajorVersion = 8;
        public static int MinorVersion = 0;
        public static int Build = 50826;
        public static int Revision = 0;
    }
}
